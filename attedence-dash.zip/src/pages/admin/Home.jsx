import React from 'react'

const Home = () => {
  return (
    <div>admin page</div>
  )
}

export default Home