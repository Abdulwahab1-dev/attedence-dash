import axios from '../api/axios';
import React,{ useState } from 'react'
import { useNavigate } from 'react-router-dom';
import AuthUser from '../component/AuthUser';



const Register = () => {

  const {http, setToken} = AuthUser();

    const [role, setRole] = useState();
  
    const [name, setName] = useState();
  
    const [email, setEmail] = useState();
  
    const [password, setPassword] = useState();
  
    const [phone_number, setPhone_number] = useState();
  
    const [designation, setDesignation] = useState();

    const navigate = useNavigate();

    const onSubmit = (e) => {
      e.preventDefault();
      http.post('/admin/register',{role:role, name:name, email:email, password:password, phone:phone_number, designation:designation }).then((res)=>{
        // setToken(res.data.user,res.data.access_token);
        navigate('/');
        alert('succesful upload');
      }) 
      
      
      // e.preventDefault();
        // console.log( role + " " +  name + " " + email + "" + password + "" + phone_number + " " + designation + "");
        // try{

            // http.axios.post('/admin/register',
            //   {role,name,email,password,phone_number,designation},
            // );
            // setName("")
            // setEmail("")
            // setRole("")
            // setPhone_number("")
            // setPassword("")
            // setDesignation("")

            // alert("successful uploaded");
            //   navigate('/')
            //   console.log(response.data);
            //   console.log(response.accessToken);
            //   console.log(JSON.stringify(response))

        // }catch (error) {
        //   alert("error");
        // }

    }

  return (
    <>
    <div>
    <div className="w-full rounded-lg border border-gray-200 bg-white p-4 shadow dark:border-gray-700 dark:bg-gray-800 sm:p-6 md:p-8">
          <form onSubmit={onSubmit} className="space-y-6" >
            <h5 className="text-xl font-medium text-gray-900 dark:text-white">
             Registration Form
            </h5>
            <div>
              <label
                for="countries"
                class="mb-2 block text-sm font-medium text-gray-900 dark:text-white"
              >
                Select an option
              </label>
              <select
                id="countries"
                class="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:border-blue-500 dark:focus:ring-blue-500"
                onChange={(e) => setRole(e.target.value)}
              >
                <option selected>Select A Role</option>
              <option value="admin">Admin</option>
              <option value="user">User</option>
              </select>
            </div>
            <div>
              <label
                htmlFor="Name"
                className="mb-2 block text-sm font-medium text-gray-900 dark:text-white"
              >
                Your Name
              </label>
              <input
                type="text"
                name="name"
                id="name"
                className="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-500 dark:bg-gray-600 dark:text-white dark:placeholder-gray-400"
                placeholder="name"
                required=""
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <div>
              <label
                htmlFor="Name"
                className="mb-2 block text-sm font-medium text-gray-900 dark:text-white"
              >
                Designation
              </label>
              <input
                type="text"
                name="Designation"
                id="name"
                className="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-500 dark:bg-gray-600 dark:text-white dark:placeholder-gray-400"
                placeholder="Designation"
                required=""
                onChange={(e) => setDesignation(e.target.value)}
              />
            </div>
            <div>
              <label
                htmlFor="email"
                className="mb-2 block text-sm font-medium text-gray-900 dark:text-white"
              >
                Your email
              </label>
              <input
                type="email"
                name="email"
                id="email"
                className="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-500 dark:bg-gray-600 dark:text-white dark:placeholder-gray-400"
                placeholder="name@company.com"
                required=""
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div>
              <label
                htmlFor="password"
                className="mb-2 block text-sm font-medium text-gray-900 dark:text-white"
              >
                Your password
              </label>
              <input
                type="password"
                name="password"
                id="password"
                placeholder="••••••••"
                className="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-500 dark:bg-gray-600 dark:text-white dark:placeholder-gray-400"
                required=""
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <div>
              <label
                htmlFor="password"
                className="mb-2 block text-sm font-medium text-gray-900 dark:text-white"
              >
                Your Phone
              </label>
              <input
                type="number"
                name="phone"
                // id="password"
                placeholder="+92123456789"
                className="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-500 dark:bg-gray-600 dark:text-white dark:placeholder-gray-400"
                required=""
                onChange={(e) => setPhone_number(e.target.value)}
              />
            </div>
            <button
              // type="submit"
              className="w-full rounded-lg bg-blue-700 px-5 py-2.5 text-center text-sm font-medium text-white hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
              onClick={onSubmit}
            >
              Registration
            </button>
          </form>
        </div>
    </div>
    </>
  )
}

export default Register