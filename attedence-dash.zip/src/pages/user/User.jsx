import React,{ useState } from 'react'

const User = () => {

  const [time, setTime] = useState('');

  const handleTimeChange = (event) => {
    setTime(event.target.value);
  }

  return (
    <>
      <div>
      <label htmlFor="time">Time:</label>
      <input
        type="time"
        id="time"
        value={time}
        onChange={handleTimeChange}
        step="1"
        min="00:00"
        max="23:59"
      />
    </div>
    </>
  )
}

export default User;