import React from 'react'
import { Route, Routes } from 'react-router-dom'
import Login from './pages/Login'
import Register from './pages/Register'
import Home from './pages/admin/Home'
import AuthUser from './component/AuthUser'
import User from './pages/user/User'


function App() {
  
  // const {getToken} = AuthUser();

  // if(!getToken()){
  //   return <Login/>
  // }

  return (
    <>
      {/* <Router> */}
        <Routes>
          <Route path='/' element={<Login/>} />
          <Route path='/register' element={<Register/>} />
          <Route path='/home' element={<Home/>} />
          <Route path='/user' element={<User/>} />
        </Routes>
      {/* </Router> */}
    </>
  )
}

export default App
